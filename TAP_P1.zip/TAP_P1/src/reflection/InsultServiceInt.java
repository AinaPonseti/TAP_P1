package reflection;

public interface InsultServiceInt {

    void addInsult(String insult);
    String getAllInsults();
    String getInsult();
}
