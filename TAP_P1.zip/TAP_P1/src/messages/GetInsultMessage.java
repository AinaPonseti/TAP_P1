package messages;

import actors.Actor;

public class GetInsultMessage extends Message{
    /**
     * Constructor for the Message class.
     */
    public GetInsultMessage() {
        super();
    }
}
