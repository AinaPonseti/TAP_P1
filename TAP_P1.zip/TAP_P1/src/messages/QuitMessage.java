package messages;

import actors.Actor;

public class QuitMessage extends Message{

    /**
     * Constructor for the Message class.
     */
    public QuitMessage() {
        super(null, null);
    }
}
